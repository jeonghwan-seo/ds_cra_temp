public class Greet {
    public static String greet(String name) {
        if (name == null || name.trim().isEmpty()) {
            name = "Guest";
        }
        return "Hello, " + name;
    }

    public static void main(String[] args) {
        System.out.println(greet("World"));
        System.out.println(greet(""));
    }
}
